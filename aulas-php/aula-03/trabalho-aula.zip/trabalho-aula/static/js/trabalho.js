$(document).ready(function(){

    $("#id_disciplina").change(function(){

        var dados = $('#id_busca_turma').serialize();

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'busca_turma.php',
            async: true,
            data: dados,
            success: function(response){
                console.log("oi");
            }
        });
    });
});
