<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Trabalho PHP - Adriano Margarin</title>
        <link rel="stylesheet" type="text/css" href="static/css/bootstrap.min.css">
        <script type="text/javascript" src="static/js/jquery.min.js"></script>
        <script type="text/javascript" src="static/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="static/js/trabalho.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-default">
            <div class="container">
                <p class="navbar-text">Trabalho PHP - Adriano Margarin</p>
            </div>
        </nav>

        <div class="row">
            <div class="container">
                <div class="col-md-6 col-md-offset-3">
                    <form class="form" id="id_busca_turma">
                        <select class="form-control" name="disciplina" id="id_disciplina">
                            <option value="">Selecione uma disciplina</option>
                            <?php
                                include('conexao.php');
                                $RESULT = mysql_query("select * from disciplina");
                                while($row = mysql_fetch_array($RESULT)){
                                    echo '<option value="'.$row["id"].'">'.$row["descricao"].'</option>';
                                }
                                mysql_free_result($RESULT);
                                mysql_close($CONEXAO);
                            ?>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>