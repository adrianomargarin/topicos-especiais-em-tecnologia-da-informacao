<?php
    include('conexao.php');
    $RESULT = mysql_query("select * from disciplina where id='".$_POST["q"]."'");
    var_dump($RESULT);

    mysql_close($CONEXAO);
?>